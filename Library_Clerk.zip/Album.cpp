/******************************************************************************
** Author: Bennet Sloan
** Date: 11/30/2017
** Description: This file implements the class "Album".
******************************************************************************/
#include "LibraryItem.hpp"
#include "Album.hpp"
using std::string;

void Album::setArtist(string art)
{
    artist = art;
}

string Album::getArtist()
{
    return artist;
}

int Album::getCheckOutLength()
{
    return CHECK_OUT_LENGTH;
}