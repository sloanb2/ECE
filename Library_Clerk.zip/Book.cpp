/******************************************************************************
** Author: Bennet Sloan
** Date: 11/30/2017
** Description: This file implements the class "Book".
******************************************************************************/
#include "LibraryItem.hpp"
#include "Book.hpp"
using std::string;

void Book::setAuthor(string auth)
{
    author = auth;
}

string Book::getAuthor()
{
    return author;
}

int Book::getCheckOutLength()
{
    return CHECK_OUT_LENGTH;
}