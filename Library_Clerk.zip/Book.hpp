/******************************************************************************
** Author: Bennet Sloan
** Date: 11/30/2017
** Description: This header file declares the class "Book".
******************************************************************************/
#ifndef BOOK_HPP
#define BOOK_HPP
#include "LibraryItem.hpp"
#include <string>
using std::string;

class Book : public LibraryItem
{
private:
    string author;

public:
    Book(string idC, string t, string auth) : LibraryItem(idC, t)
    {
        setAuthor(auth);
    }
    static const int CHECK_OUT_LENGTH = 21;
    void setAuthor(string aut);
    string getAuthor();
    int getCheckOutLength(); // Override pure virtual function in parent class
};
#endif