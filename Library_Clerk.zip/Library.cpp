/******************************************************************************
** Author: Bennet Sloan
** Date: 11/30/2017
** Description: This file implements the class "Library".
******************************************************************************/
#include <iostream>
#include <string>
#include <vector>
#include "Library.hpp"
#include "Patron.hpp"
#include "LibraryItem.hpp"
using namespace std;

Library::Library() 
{
    currentDate = 0;
}

void Library::addLibraryItem(LibraryItem* item) 
{
    item->setLocation(ON_SHELF);
    holdings.push_back(item);
    cout << "Item has been added successfully." << endl;
}

void Library::addPatron(Patron* p) 
{
    members.push_back(p);
    cout << "Patron has been added successfully." << endl;
}


LibraryItem* Library::getLibraryItem(string itemID) 
{
    for (int i=0; i<holdings.size(); i++) 
    {
        if (itemID == holdings[i]->getIdCode()) 
        {
            return holdings[i];
        }
    }
    return NULL;
}

Patron* Library::getPatron(string patronID) 
{
    for (int i=0; i<members.size(); i++) 
    {
        if (patronID == members[i]->getIdNum()) 
        {
            return members[i];
        }
    }
    return NULL;
}

string Library::checkOutLibraryItem(string pID, string itemID)
{
    LibraryItem *item = getLibraryItem(itemID);
    Patron *patron = getPatron(pID);

    if (!item)
    {
        return "item not found";
    }

    if (!patron)
    {
        return "patron not found";
    }

    Locale status = item->getLocation();
     
    if (status == CHECKED_OUT)
    {
        return "item already checked out";
    }

    if (status == ON_HOLD_SHELF)
    {
        if (item->getRequestedBy() != patron)
        {
            return "item on hold by other patron";
        }
        else 
        {
            item->setRequestedBy(NULL);
        }
    }

    item->setCheckedOutBy(patron);
    item->setDateCheckedOut(currentDate);
    item->setLocation(CHECKED_OUT);

    patron->addLibraryItem(item);
    return "check out successful";
}


string Library::returnLibraryItem(string itemID)
{
    LibraryItem *item = getLibraryItem(itemID);

    if (!item)
    {
        return "item not found";
    }

    Locale status = item->getLocation();
    if (status != CHECKED_OUT)
    {
        return "item already in library";
    }
    Patron *patron = item->getCheckedOutBy();
    patron->removeLibraryItem(item);
    
    if (item->getRequestedBy())
    {
        item->setLocation(ON_HOLD_SHELF);
    }
    else
    {
        item->setLocation(ON_SHELF);
    }

    item->setCheckedOutBy(NULL);
    return "return successful";
}

string Library::requestLibraryItem(string pID, string itemID)
{
    LibraryItem *item = getLibraryItem(itemID);
    Patron *patron = getPatron(pID);

    if (!item)
    {
        return "item not found";
    }

    if (!patron)
    {
        return "patron not found";
    }

    Locale status = item->getLocation();

    if (status == ON_HOLD_SHELF)
    {
        if (item->getRequestedBy() != patron)
        {
            return "item already on hold";
        }
    }

    if (status == ON_SHELF)
    {
        item->setLocation(ON_HOLD_SHELF);
    }
    item->setRequestedBy(patron);
    return "request successful";
}


string Library::payFine(string pID, double payment)
{
    Patron *patron = getPatron(pID);

    if (!patron)
    {
        return "patron not found";
    }

    patron->amendFine(-payment);
    return "payment successful";
}


void Library::incrementCurrentDate()
{
    ++currentDate;

    for (int i=0; i<holdings.size(); i++)
    {
        LibraryItem *item = holdings[i];
        int checkOutLength = item->getCheckOutLength();
        int dateCheckedOut = item->getDateCheckedOut();
        int dueDate = dateCheckedOut + checkOutLength;
        int daysOverdue = currentDate - dueDate;
          
        if (daysOverdue > 0)
        {
            Patron *patron = item->getCheckedOutBy();

            if (patron != NULL)
            {
                patron->amendFine(0.10);
            }
        }
    }
}