/******************************************************************************
** Author: Bennet Sloan
** Date: 11/30/2017
** Description: This file implements the class "LibraryItem".
******************************************************************************/
#include "LibraryItem.hpp"
#include <string>
using std::string;

LibraryItem::LibraryItem(string idC, string t)
{
    idCode = idC;
    title = t;
    setCheckedOutBy(NULL);
    setRequestedBy(NULL);
    setLocation(ON_SHELF);
}

string LibraryItem::getIdCode()
{
    return idCode;
}

string LibraryItem::getTitle()
{
    return title;
}

Locale LibraryItem::getLocation()
{
    return location;
}

void LibraryItem::setLocation(Locale loc)
{
    location = loc;
}

Patron* LibraryItem::getCheckedOutBy()
{
    return checkedOutBy;
}

void LibraryItem::setCheckedOutBy(Patron *checkBy)
{
    checkedOutBy = checkBy;
}

Patron* LibraryItem::getRequestedBy()
{
    return requestedBy;
}

void LibraryItem::setRequestedBy(Patron* pReqBy)
{
    requestedBy = pReqBy;
}

int LibraryItem::getDateCheckedOut()
{
    return dateCheckedOut;
}

void LibraryItem::setDateCheckedOut(int date)
{
    dateCheckedOut = date;
}