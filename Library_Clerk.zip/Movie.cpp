/******************************************************************************
** Author: Bennet Sloan
** Date: 11/30/2017
** Description: This file implements the class "Movie".
******************************************************************************/
#include "LibraryItem.hpp"
#include "Movie.hpp"

void Movie::setDirector(string d)
{
    director = d;
}

string Movie::getDirector()
{
    return director;
}

int Movie::getCheckOutLength()
{
    return CHECK_OUT_LENGTH;
}