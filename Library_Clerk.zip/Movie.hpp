/******************************************************************************
** Author: Bennet Sloan
** Date: 11/30/2017
** Description: This header file declares the class "Movie".
******************************************************************************/
#ifndef MOVIE_HPP
#define MOVIE_HPP
#include "LibraryItem.hpp"
#include <string>
using std::string;

class Movie : public LibraryItem
{
private:
    string director;
public:
    Movie(string idC, string t, string d) : LibraryItem(idC, t)
    {
        setDirector(d);
    }
    static const int CHECK_OUT_LENGTH = 7;
    void setDirector(string d);
    string getDirector();
    int getCheckOutLength(); // Override pure virtual function in parent class
};
#endif
