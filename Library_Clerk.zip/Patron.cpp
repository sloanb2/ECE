/******************************************************************************
** Author: Bennet Sloan
** Date: 11/30/2017
** Description: This file implements the class "Patron".
******************************************************************************/
#include "LibraryItem.hpp"
#include "Patron.hpp"
using std::string;

Patron::Patron(string idn, string n)
{
    idNum = idn;
    name = n;
}

string Patron::getIdNum()
{
    return idNum;
}

string Patron::getName()
{
    return name;
}

std::vector<LibraryItem*> Patron::getCheckedOutItems()
{
    return checkedOutItems;
}

void Patron::addLibraryItem(LibraryItem* add)
{
    checkedOutItems.push_back(add);
}

void Patron::removeLibraryItem(LibraryItem* remove)
{
    string id;
    id = remove->getIdCode();
    int size = checkedOutItems.size();

    for (int index = 0; index < size; index++)
    {
        if ((checkedOutItems[index]->getIdCode()) == id)
        {
            checkedOutItems.erase(checkedOutItems.begin() + index);
            size = index;
        }
    }
}

double Patron::getFineAmount()
{
    return fineAmount;
}

void Patron::amendFine(double amount)
{
    fineAmount += amount;
}
