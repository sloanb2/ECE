function [x,y,z] = my3DFc(t,n,d)
% my3DFc creates a 3d plot from parameter t
x = cos((n/d).*t).*cos(t);
y = cos((n/d).*t).*sin(t);
z = cos(t);
end

