function [z] = mySrfF(s,t)
% mySrfF 
z = sin(s) + cos(t);
end

