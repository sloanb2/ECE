%% Author:      Bennet Sloan
%% Date:        8/13/2018
%% Assignment:  Lab 9
%% Description: This script 
%% Clear the window, variables & figs
clear 
clc
clf

dx = 5;
dy = 1.5;

mTrans = eye(3);    % Translation matrix
mTrans(1,3) = dx;
mTrans(2,3) = dy;

subplot(2,2,1)
DrawHouse( eye(3) );
DrawHouse( mTrans );
axis equal;
title('Translation');

t = 25; % theta in degrees

mRot = [cosd(t), sind(t), 0;... % Rotation matrix
    -sind(t), cosd(t), 0;...
    0, 0 , 1];

subplot(2,2,2)
DrawHouse( eye(3) );
DrawHouse( mRot );
axis equal;
title('Rotation');

subplot(2,2,3)
DrawHouse( eye(3) );
DrawHouse( mRot*mTrans );
axis equal;
title('Translate Rotate');  % translate then rotate

subplot(2,2,4)
DrawHouse( eye(3) );
DrawHouse( mTrans*mRot );
axis equal;
title('Rotate Translate');  % rotate then translate

