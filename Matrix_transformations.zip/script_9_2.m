%% Author:      Bennet Sloan
%% Date:        8/13/2018
%% Assignment:  Lab 9
%% Description: This script uses transformation matrices on a plot
%% Clear the window, variables & figs
clear 
clc
clf

theta = linspace(0,6*pi,200);
n = 4;
d = 3;
x = cos((n/d).*theta).*cos(theta);  % uses t bounds as inteval
y = cos((n/d).*theta).*sin(theta);
plot(x,y);
axis equal
hold on

pts = [x; y; ones( 1, length(x) ) ];

dx = 5;
dy = 1.5;
mTrans = eye(3);    % Translation matrix
mTrans(1,3) = dx;
mTrans(2,3) = dy;

t = 45; % theta in degrees
mRot = [cosd(t), sind(t), 0;... % Rotation matrix
    -sind(t), cosd(t), 0;...
    0, 0 , 1];

ptsNew = mTrans * mRot * pts;

for k=1:3
    plot(ptsNew(1,:),ptsNew(2,:),'-r');
    dx = dx+2;
    mTrans(1,3) = dx;
    ptsNew = mTrans * mRot * pts;
end