%% Author:      Bennet Sloan
%% Date:        8/13/2018
%% Assignment:  Lab 9
%% Description: This script plots a surface
%% Clear the window, variables & figs
clear 
clc
clf
 
subplot(1,2,1)
t = linspace(0,50,600);
[x, y, z] = my3DFc( t,5,5 );
plot3(x,y,z);

subplot(1,2,2)
s = linspace(-pi, pi);
t = linspace(-pi, pi);
[S, T] = meshgrid(s,t);
Z = mySrfF(S,T);
surf( S, T, Z, 'FaceColor', [ 0.5 0.5 0.5], 'EdgeColor', 'b');
camlight left;
lighting phong;
view( 45, 60 );
axis equal